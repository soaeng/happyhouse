package com.ssafy.happyhouse.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.dto.HouseDto;
import com.ssafy.happyhouse.dto.SurroundingDto;
import com.ssafy.happyhouse.service.SurroundingService;

import lombok.extern.log4j.Log4j2;

@RestController
@CrossOrigin(
	    origins = "http://localhost:5500",
	    allowCredentials = "true", 
	    allowedHeaders = "*", 
	    methods = {RequestMethod.GET,RequestMethod.POST,RequestMethod.DELETE,RequestMethod.PUT,RequestMethod.HEAD,RequestMethod.OPTIONS}
	)
@Log4j2
public class SurroundingController {

	@Autowired
	SurroundingService service;
	
	// 스벅 목록
	@GetMapping("/house/cafe")
	public ResponseEntity<List<SurroundingDto>> cafeList(HouseDto house){
		// log.info("===== 카페 목록 controller =====");

		Map<String, String> map = new HashMap<String, String>();
		map.put("lat", house.getLat());
		map.put("lng", house.getLng());		
		
		List<SurroundingDto> list = service.cafeList(map);
		
		// list.forEach(cafe -> log.info(cafe));
		
		return new ResponseEntity<List<SurroundingDto>>(list, HttpStatus.OK);
	}

	// 학교 목록
	@GetMapping("/house/school")
	public ResponseEntity<List<SurroundingDto>> schoolList(HouseDto house){
		// log.info("===== 학교 목록 controller =====");
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("lat", house.getLat());
		map.put("lng", house.getLng());		
		
		List<SurroundingDto> list = service.schoolList(map);
		
		return new ResponseEntity<List<SurroundingDto>>(list, HttpStatus.OK);
	}

	// 버스 목록
	@GetMapping("/house/bus")
	public ResponseEntity<List<SurroundingDto>> busList(HouseDto house){
		// log.info("===== 학교 목록 controller =====");
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("lat", house.getLat());
		map.put("lng", house.getLng());		
		
		List<SurroundingDto> list = service.busStopList(map);
		
		return new ResponseEntity<List<SurroundingDto>>(list, HttpStatus.OK);
	}
}
