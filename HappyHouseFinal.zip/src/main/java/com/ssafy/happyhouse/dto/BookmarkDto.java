package com.ssafy.happyhouse.dto;

import lombok.Data;

@Data
public class BookmarkDto {
	
	private int userSeq;
	private String dongCode;
	private int houseNo;
	private int dealNo;
	
}
